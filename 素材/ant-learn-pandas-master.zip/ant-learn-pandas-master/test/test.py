# 输出一行字符串
print("hello python")
# 执行算数运算
print(3*(5-2))