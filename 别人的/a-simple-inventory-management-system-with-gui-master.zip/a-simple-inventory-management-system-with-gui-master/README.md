# a simple inventory management system with gui

- - -

gui_version.py  **主要代码**

dict/ 使用pyinstaller打包为exe后的版本

pycache/ 图片缓存文件

img.py 将图片转换为base64编码的.py文件

icon.py 软件主页面左上角图标的base64编码形式

header.py 软件主页面图片的base64编码形式

setup.bat （需要pyinstaller）打包快捷脚本

1.ico 打包时所需图标文件

record.txt 记录软件打开次数，*不可删除!!!*

inventory.db 数据库文件，删除后会自动重建（即重置数据库）

